import { Component } from '@angular/core';

@Component({
	selector: 'app-user-icon',
	templateUrl: './user-icon.component.html',
	styleUrls: []
})
export class UserIconComponent {

}
