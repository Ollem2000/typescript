import { Component } from '@angular/core';

@Component({
	selector: 'app-bell-icon',
	templateUrl: './bell-icon.component.html',
	styleUrls: []
})
export class BellIconComponent {

}
