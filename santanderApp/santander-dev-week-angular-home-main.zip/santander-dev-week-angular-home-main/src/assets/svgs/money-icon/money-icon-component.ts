import { Component } from '@angular/core';

@Component({
	selector: 'app-money-icon',
	templateUrl: './money-icon-component.html',
	styleUrls: []
})
export class MoneyIconComponent {

}
